import re
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# -------------------------------
# 🔐 VALIDATION FUNCTIONS
# -------------------------------
def validate_login_data(data):
    return (
        isinstance(data, dict) and
        "pen" in data and isinstance(data["pen"], str) and
        "password" in data and isinstance(data["password"], str)
    )

def validate_registration_data(data):
    required_fields = ["firstName", "surname", "email", "pen", "password", "confirmPassword"]
    for field in required_fields:
        if field not in data or not data[field].strip():
            return False

    if data["password"] != data["confirmPassword"]:
        return False

    # Validate email format
    if not re.match(r"^[\w\.-]+@[\w\.-]+\.\w+$", data["email"]):
        return False

    # Validate password length
    if len(data["password"]) < 8:
        return False

    return True
