from marshmallow import Schema, fields

class UserSchema(Schema):
    id = fields.Int()
    first_name = fields.Str()
    surname = fields.Str()
    other_names = fields.Str()
    email = fields.Email()
    pen_number = fields.Str()
    is_verified = fields.Bool()
    verification_message = fields.Str()
    created_at = fields.DateTime()
