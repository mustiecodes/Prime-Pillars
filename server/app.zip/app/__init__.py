from flask import Flask
from app.config import Config
from app.extensions import db, mail, login_manager, migrate
from app.routes.auth import auth_bp
from app.routes.application import application_bp
from app.models import User
from app.errors import register_error_handlers
from flask_wtf import CSRFProtect
import logging
from logging.handlers import RotatingFileHandler
import os
from flask_cors import CORS

csrf = CSRFProtect()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Init extensions
    db.init_app(app)
    mail.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)
    
    # Allow requests from your frontend (localhost:3000)
    CORS(app, supports_credentials=True, origins=["http://localhost:3000"])

    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(application_bp, url_prefix='/api')

    # Login manager config
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Register global error handlers
    register_error_handlers(app)

    # Logging
    if not os.path.exists('logs'):
        os.mkdir('logs')

    file_handler = RotatingFileHandler('logs/app.log', maxBytes=10240, backupCount=3)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)

    app.logger.setLevel(logging.INFO)
    app.logger.info('App startup')

    return app
