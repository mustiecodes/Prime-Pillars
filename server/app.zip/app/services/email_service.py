from flask_mail import Message
from app.extensions import mail

def send_verification_email(to_email, is_verified, message):
    subject = "Verification Result"
    if is_verified:
        body = f"✅ Your verification was successful.\n\n{message}"
    else:
        body = f"❌ Your verification failed.\n\nReason: {message}"

    msg = Message(subject=subject, recipients=[to_email], body=body)
    mail.send(msg)
