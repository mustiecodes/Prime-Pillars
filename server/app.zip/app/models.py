from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from .extensions import db

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100))
    surname = db.Column(db.String(100))
    other_names = db.Column(db.String(100))
    email = db.Column(db.String(120), nullable=False)
    pen_number = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_verified = db.Column(db.Boolean, default=False)
    verification_message = db.Column(db.Text, default="Pending verification")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

class UserProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True)
    pfa = db.Column(db.String(100))
    rsa_balance = db.Column(db.String(100))
    bvn = db.Column(db.String(20))
    nin = db.Column(db.String(20))
    dob = db.Column(db.Date)
    phone1 = db.Column(db.String(20))
    phone2 = db.Column(db.String(20))
    alt_email = db.Column(db.String(100))

class DocumentUpload(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    doc_type = db.Column(db.String(100))  # e.g., 'NIN Slip', 'Account Opening'
    title = db.Column(db.String(255))     # for optional docs
    file_path = db.Column(db.String(255))
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
