import os
from flask import Blueprint, request, jsonify, session, current_app
from werkzeug.utils import secure_filename
from app.models import db, User, UserProfile, OtherDocument

customer_bp = Blueprint("customer", __name__, url_prefix="/api/customer")

def save_file(file):
    filename = secure_filename(file.filename)
    upload_path = os.path.join("uploads", filename)
    full_path = os.path.join(current_app.root_path, upload_path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    file.save(full_path)
    return upload_path

@customer_bp.route("/profile", methods=["POST"])
def submit_profile():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"message": "Unauthorized"}), 401

    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404

    if user.profile:
        return jsonify({"message": "Profile already submitted"}), 400

    form = request.form
    files = request.files

    try:
        profile = UserProfile(
            user_id=user.id,
            pfa=form.get("pfa", ""),
            rsa_balance=form.get("rsa_balance", ""),
            bvn=form.get("bvn", ""),
            nin=form.get("nin", ""),
            dob=form.get("dob", ""),
            phone1=form.get("phone1", ""),
            phone2=form.get("phone2", ""),
            alt_email=form.get("alt_email", ""),
            account_opening_form=save_file(files.get("account_opening_form")) if "account_opening_form" in files else None,
            nin_slip=save_file(files.get("nin_slip")) if "nin_slip" in files else None,
            undertaken_form=save_file(files.get("undertaken_form")) if "undertaken_form" in files else None,
            consent_form=save_file(files.get("consent_form")) if "consent_form" in files else None,
            indemnity_form=save_file(files.get("indemnity_form")) if "indemnity_form" in files else None,
            application_letter=save_file(files.get("application_letter")) if "application_letter" in files else None,
        )

        db.session.add(profile)
        db.session.flush()  # Get profile.id

        index = 0
        while True:
            title_key = f"other_titles[{index}]"
            file_key = f"other_files[{index}]"
            if title_key in form and file_key in files:
                title = form[title_key]
                file = files[file_key]
                file_path = save_file(file)

                other_doc = OtherDocument(title=title, file_path=file_path, profile_id=profile.id)
                db.session.add(other_doc)
                index += 1
            else:
                break

        db.session.commit()
        return jsonify({"message": "Profile submitted successfully"}), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Something went wrong", "error": str(e)}), 500
