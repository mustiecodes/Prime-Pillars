from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from app.models import Application, Document, Feedback, Offer, AccountRecord, db
from utils.email_utils import send_feedback_email
from datetime import datetime

user_bp = Blueprint('user', __name__, url_prefix='/api/user')

def check_permission(app_obj):
    # Example: ensure current_user.role == "user"
    return True

@user_bp.route('/applications/submitted', methods=['GET'])
@login_required
def list_submitted():
    apps = Application.query.filter_by(status='submitted').all()
    return jsonify([app.serialize() for app in apps]), 200

@user_bp.route('/applications/approved', methods=['GET'])
@login_required
def list_approved():
    apps = Application.query.filter_by(status='approved').all()
    return jsonify([app.serialize() for app in apps]), 200

@user_bp.route('/applications/<int:app_id>', methods=['GET'])
@login_required
def view_application(app_id):
    app_obj = Application.query.get_or_404(app_id)
    if not check_permission(app_obj):
        return jsonify({"error": "No permission"}), 403
    return jsonify(app_obj.to_dict(include_documents=True)), 200

@user_bp.route('/applications/<int:app_id>/document/<int:doc_id>', methods=['POST'])
@login_required
def review_document(app_id, doc_id):
    data = request.json
    decision = data.get('decision')  # 'accept' or 'reject'
    comment = data.get('comment', '')

    doc = Document.query.filter_by(application_id=app_id, id=doc_id).first_or_404()
    doc.status = decision
    db.session.commit()

    # If reject, prevent overall submit
    app = doc.application
    if decision == 'reject':
        app.status = 'submitted_with_rejection'
        feedback = Feedback(
            application_id=app_id,
            document_id=doc_id,
            comment=comment,
            by_user=current_user.id,
            created_at=datetime.utcnow()
        )
        db.session.add(feedback)
        db.session.commit()

    return jsonify({"message": "Document reviewed"}), 200

@user_bp.route('/applications/<int:app_id>/submit', methods=['POST'])
@login_required
def finalize_application(app_id):
    app = Application.query.get_or_404(app_id)
    if any(doc.status != 'accept' for doc in app.documents):
        return jsonify({"error": "Pending rejections"}), 400

    app.status = 'approved'
    app.submitted_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"message": "Application submitted for approval"}), 200

@user_bp.route('/applications/<int:app_id>/feedback/send', methods=['POST'])
@login_required
def send_feedback(app_id):
    app = Application.query.get_or_404(app_id)
    feedbacks = Feedback.query.filter_by(application_id=app_id).all()
    send_feedback_email(app, feedbacks)
    return jsonify({"message": "Feedback sent"}), 200

@user_bp.route('/applications/<int:app_id>/offer', methods=['POST'])
@login_required
def create_offer(app_id):
    app = Application.query.get_or_404(app_id)
    if app.status != 'approved':
        return jsonify({"error": "Not ready"}), 400

    offer = Offer(application_id=app_id, amount=app.rsa_balance * 0.05, created_at=datetime.utcnow())
    db.session.add(offer)
    db.session.commit()
    return jsonify(offer.serialize()), 201

@user_bp.route('/applications/<int:app_id>/downloads', methods=['GET'])
@login_required
def download_docs(app_id):
    app = Application.query.get_or_404(app_id)
    data = {
        "account_opening": app.docs_by_type("account_opening"),
        "other_docs": app.docs_excluding("account_opening")
    }
    return jsonify(data), 200

@user_bp.route('/reports/offers', methods=['GET'])
@login_required
def reports_offers():
    start = request.args.get('start')
    end = request.args.get('end')
    offers = Offer.query.filter(Offer.created_at.between(start, end)).all()
    return jsonify([o.serialize() for o in offers]), 200

@user_bp.route('/reports/approved', methods=['GET'])
@login_required
def reports_approved():
    apps = Application.query.filter_by(status='approved').all()
    return jsonify([a.to_dict() for a in apps]), 200

@user_bp.route('/accounts/upload_record', methods=['POST'])
@login_required
def upload_account_record():
    file = request.files.get('file')
    if not file:
        return jsonify({"error": "File is required"}), 400

    # Parse Excel and insert/update AccountRecord
    # Ensure no duplicates
    count = AccountRecord.bulk_insert_from_excel(file)
    return jsonify({"message": f"{count} records added/updated"}), 200

@user_bp.route('/accounts/search', methods=['GET'])
@login_required
def search_account():
    q = request.args.get('q', '')
    records = AccountRecord.search(q)
    return jsonify([r.serialize() for r in records]), 200
