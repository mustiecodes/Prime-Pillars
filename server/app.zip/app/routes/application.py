from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
import os
from werkzeug.utils import secure_filename
from datetime import datetime

from app.models import UserProfile, DocumentUpload
from app.extensions import db
from app.forms.application_forms import ApplicationForm

application_bp = Blueprint('application', __name__)

MANDATORY_DOCS = [
    'account_opening_form', 'nin_slip', 'undertaken_form',
    'consent_form', 'indemnity_form', 'application_letter', 'etc'
]

@application_bp.route('/apply', methods=['POST'])
@login_required
def submit_application():
    form = ApplicationForm()
    if not form.validate_on_submit():
        return jsonify({"errors": form.errors}), 400

    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        profile = UserProfile(user_id=current_user.id)

    profile.pfa = form.pfa.data
    profile.rsa_balance = form.rsa_balance.data
    profile.bvn = form.bvn.data
    profile.nin = form.nin.data
    profile.dob = form.dob.data
    profile.phone1 = form.phone1.data
    profile.phone2 = form.phone2.data
    profile.alt_email = form.alt_email.data
    db.session.add(profile)

    upload_folder = os.path.join(current_app.config['UPLOAD_FOLDER'], str(current_user.id))
    os.makedirs(upload_folder, exist_ok=True)

    # Handle required files
    for doc_key in MANDATORY_DOCS:
        if doc_key not in request.files:
            return jsonify({"error": f"Missing required document: {doc_key}"}), 400

        file = request.files[doc_key]
        filename = secure_filename(f"{doc_key}_{datetime.utcnow().isoformat()}.pdf")
        filepath = os.path.join(upload_folder, filename)
        file.save(filepath)

        doc = DocumentUpload(
            user_id=current_user.id,
            doc_type=doc_key.replace('_', ' ').title(),
            file_path=filepath
        )
        db.session.add(doc)

    # Handle other docs
    other_titles = request.form.getlist('other_titles[]')
    other_files = request.files.getlist('other_files[]')
    for title, file in zip(other_titles, other_files):
        filename = secure_filename(f"{title}_{datetime.utcnow().isoformat()}.pdf")
        filepath = os.path.join(upload_folder, filename)
        file.save(filepath)

        doc = DocumentUpload(
            user_id=current_user.id,
            doc_type="Other",
            title=title,
            file_path=filepath
        )
        db.session.add(doc)

    db.session.commit()
    return jsonify({"message": "Application submitted successfully"}), 200
