from flask import Blueprint, request, jsonify
from flask_login import login_user, logout_user
from app.models import User
from app.extensions import db
from app.forms.auth_forms import RegisterForm, LoginForm
from app.schemas.user_schema import UserSchema
from flask_login import current_user, login_required

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/me', methods=['GET'])
@login_required
def me():
    return jsonify(UserSchema().dump(current_user)), 200


@auth_bp.route('/register', methods=['POST'])
def register():
    form = RegisterForm(data=request.json)
    if not form.validate():
        return jsonify({"errors": form.errors}), 400

    if User.query.filter_by(pen_number=form.pen_number.data).first():
        return jsonify({'error': 'PEN number already exists'}), 409

    user = User(
        first_name=form.first_name.data,
        surname=form.surname.data,
        other_names=form.other_names.data,
        email=form.email.data,
        pen_number=form.pen_number.data,
        is_verified=False,
        verification_message="Pending verification"
    )
    user.set_password(form.password.data)
    db.session.add(user)
    db.session.commit()

    return jsonify({"message": "Registration submitted. You'll be notified after verification."}), 201


@auth_bp.route('/login', methods=['POST'])
def login():
    form = LoginForm(data=request.json)
    if not form.validate():
        return jsonify({"errors": form.errors}), 400

    user = User.query.filter_by(pen_number=form.pen_number.data).first()
    if not user or not user.check_password(form.password.data):
        return jsonify({'error': 'Invalid credentials'}), 401

    if not user.is_verified:
        return jsonify({
            'error': 'Account not verified',
            'message': user.verification_message
        }), 403

    login_user(user)
    user_data = UserSchema().dump(user)
    return jsonify({"message": "Login successful", "user": user_data})

@auth_bp.route('/logout', methods=['POST'])
def logout():
    logout_user()
    return jsonify({"message": "Logged out successfully"})
