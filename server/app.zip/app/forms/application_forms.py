from flask_wtf import FlaskForm
from wtforms import StringField, DateField
from wtforms.validators import DataRequired, Email

class ApplicationForm(FlaskForm):
    pfa = StringField('PFA', validators=[DataRequired()])
    rsa_balance = StringField('RSA Balance', validators=[DataRequired()])
    bvn = StringField('BVN', validators=[DataRequired()])
    nin = StringField('NIN', validators=[DataRequired()])
    dob = DateField('Date of Birth', validators=[DataRequired()])
    phone1 = StringField('Phone Number 1', validators=[DataRequired()])
    phone2 = StringField('Phone Number 2')
    alt_email = StringField('Alt Email', validators=[Email()])
